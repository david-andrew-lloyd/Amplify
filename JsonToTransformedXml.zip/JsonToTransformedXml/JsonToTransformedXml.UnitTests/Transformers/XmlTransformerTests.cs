﻿namespace JsonToTransformedXml.UnitTests.Transformers
{
    using System;
    using System.IO;
    using JsonToTransformedXml.Transformers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Unit tests for the XmlTransformer
    /// </summary>
    [TestClass]
    [DeploymentItem(@"TestFiles")]
    public class XmlTransformerTests
    {  
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TransformJsonToXmlDocumentNullFilename()
        {
            try
            {
                var xmlTransformer = new XmlTransformer();
                xmlTransformer.TransformJsonToXmlDocument(null);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("file does not exist: ", ex.Message);
                throw;                
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TransformJsonToXmlDocumentEmptyStringFilename()
        {
            try
            {
                var xmlTransformer = new XmlTransformer();
                xmlTransformer.TransformJsonToXmlDocument(string.Empty);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("file does not exist: ", ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void TransformJsonToXmlDocument()
        {
            var xmlTransformer = new XmlTransformer();
            var baseDir = AppDomain.CurrentDomain.BaseDirectory;
            var inputFile = Path.Combine(baseDir, "1280.json");

            Assert.IsTrue(File.Exists(inputFile));
            var xmlDocument = xmlTransformer.TransformJsonToXmlDocument(inputFile);
            Assert.AreEqual(Resource._1280, xmlDocument.OuterXml);           
        }
    }
}
