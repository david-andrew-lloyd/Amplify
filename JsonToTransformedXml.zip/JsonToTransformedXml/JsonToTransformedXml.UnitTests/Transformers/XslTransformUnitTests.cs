﻿namespace JsonToTransformedXml.UnitTests.Transformers
{
    using System;
    using System.Xml;
    using JsonToTransformedXml.Transformers;    
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class XslTransformUnitTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransformNullSource()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: source");
            try
            {
                var xslTransform = new XslTransform();
                var transform = xslTransform.Transform(null, null, null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransformNullXslt()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: xslt");
            try
            {
                var xslTransform = new XslTransform();
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml("<root/>");
                var transform = xslTransform.Transform(xmlDocument.CreateNavigator(), null, null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void Transform()
        {
            var xslTransform = new XslTransform();
            var xmlSourceDocument = new XmlDocument();
            xmlSourceDocument.LoadXml("<root>1</root>");
            var xslt = new XmlDocument();
            xslt.LoadXml(Resource.TestXslt);
            var xmlDestDocument = new XmlDocument();
            xmlDestDocument.LoadXml("<test>1</test>");

            var transform = xslTransform.Transform(xmlSourceDocument.CreateNavigator(), xslt.CreateNavigator(), null);
            Assert.AreEqual(xmlDestDocument.CreateNavigator().OuterXml, transform);
        }
    }
}
