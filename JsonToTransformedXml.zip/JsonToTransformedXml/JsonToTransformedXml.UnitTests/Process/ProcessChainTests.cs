﻿namespace JsonToTransformedXml.UnitTests.Process
{
    using System;
    using System.IO;
    using JsonToTransformedXml.Process;
    using JsonToTransformedXml.Helpers;
    using JsonToTransformedXml.Loggers;
    using JsonToTransformedXml.Transformers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;

    [TestClass]
    [DeploymentItem(@"TestFiles")]
    public class ProcessChainTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessChainNullLogger()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: logger");
            try
            {
                var process = new ProcessChain(null, null, null, null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessChainNullFileHelper()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: fileHelper");
            try
            {
                var process = new ProcessChain(new Logger(), null, null, null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessChainNullxmlTransformer()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: xmlTransformer");
            try
            {
                var process = new ProcessChain(new Logger(), new FileHelper(), null, null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessChainNullxslTransform()
        {
            var expectedError = string.Concat("Value cannot be null.", Environment.NewLine, "Parameter name: xslTransform");
            try
            {
                var process = new ProcessChain(new Logger(), new FileHelper(), new XmlTransformer(), null);
            }
            catch (ArgumentNullException ex)
            {
                Assert.AreEqual(expectedError, ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ExecuteProcessChainEmptyInputDirectory()
        {
            var logger = new Mock<ILogger>();
            var fileHelper = new Mock<IFileHelper>();
            var xmlTransformer = new Mock<IXmlTransformer>();
            var xslTransform = new Mock<IXslTransform>();

            var processChain = new ProcessChain(logger.Object, fileHelper.Object, xmlTransformer.Object, xslTransform.Object);

            try
            {
                var filesProcessed = processChain.ExecuteProcessChain(string.Empty, string.Empty);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("inputDirectory cannot be found: ", ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ExecuteProcessChainEmptyFileExtensionToProcess()
        {
            var logger = new Mock<ILogger>();
            var fileHelper = new Mock<IFileHelper>();
            var xmlTransformer = new Mock<IXmlTransformer>();
            var xslTransform = new Mock<IXslTransform>();

            var processChain = new ProcessChain(logger.Object, fileHelper.Object, xmlTransformer.Object, xslTransform.Object);

            try
            {
                var inputDirectory = AppDomain.CurrentDomain.BaseDirectory;
                var filesProcessed = processChain.ExecuteProcessChain(inputDirectory, "test", string.Empty);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("fileExtensionToProcess is null or empty string", ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void ExecuteProcessChain()
        {
            var logger = new Mock<ILogger>();
            var fileHelper = new Mock<IFileHelper>();
            var xmlTransformer = new XmlTransformer();
            var xslTransform = new XslTransform();

            logger.Setup(x => x.Log(It.IsAny<string>()));
            fileHelper.Setup(x => x.SaveFile(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));           
            var file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "1280.json");
            string[] files = { file };
            fileHelper.Setup(x => x.GetFileNames(It.IsAny<string>(), It.IsAny<string>())).Returns(files);

            var processChain = new ProcessChain(logger.Object, fileHelper.Object, xmlTransformer, xslTransform);            
            var numFilesProcessed = processChain.ExecuteProcessChain(AppDomain.CurrentDomain.BaseDirectory, "TransformTests");
            Assert.AreEqual(1, numFilesProcessed.Result);
        }
    }
}
