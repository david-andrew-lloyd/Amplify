﻿namespace JsonToTransformedXml.UnitTests.Helpers
{
    using JsonToTransformedXml.Helpers;
    using System;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Unit tests for the FileHelper class
    /// </summary>
    [TestClass]
    public class FileHelperTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetFileNamesNullInputDirectory()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.GetFileNames(null, "*.json");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Unable To Find inputDirectory: ", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetFileNamesEmptyStringInputDirectory()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.GetFileNames(string.Empty, "*.json");
            }
            catch(ArgumentException ex)
            {
                Assert.AreEqual("Unable To Find inputDirectory: ", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetFileNamesNullSearchExtension()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.GetFileNames(Directory.GetCurrentDirectory(), null);
            }
            catch(ArgumentException ex)
            {
                Assert.AreEqual("searchExtension appears to be null or empty string", ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetFileNamesEmptyStringSearchExtension()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.GetFileNames(Directory.GetCurrentDirectory(), string.Empty);
            }
            catch(ArgumentException ex)
            {
                Assert.AreEqual("searchExtension appears to be null or empty string", ex.Message);
                throw;
            }
        }

        [TestMethod]
        public void GetFileNames()
        {
            var fileHelper = new FileHelper();
            var filenames = fileHelper.GetFileNames(Directory.GetCurrentDirectory(), "*.*");
            Assert.IsTrue(filenames.Length >= 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileNullContent()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.SaveFile(null, Directory.GetCurrentDirectory(), "SomeFile.json");
            }
            catch(ArgumentException ex)
            {
                Assert.AreEqual("content is null or empty string", ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileEmptyStringContent()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.SaveFile(string.Empty, Directory.GetCurrentDirectory(), "SomeFile.json");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("content is null or empty string", ex.Message);
                throw;
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileNullDirectory()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.SaveFile("SomeContent", null, "SomeFile.json");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("directory does not exist: ", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileNullFileName()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.SaveFile("SomeContent", Directory.GetCurrentDirectory(), null);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("fileName is null or empty string", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileEmptyStringFileName()
        {
            try
            {
                var fileHelper = new FileHelper();
                fileHelper.SaveFile("SomeContent", Directory.GetCurrentDirectory(), string.Empty);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("fileName is null or empty string", ex.Message);
                throw;
            }     
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SaveFileDuplicateFileRaisesException()
        {
            var fileHelper = new FileHelper();
            fileHelper.SaveFile("SomeContent", Directory.GetCurrentDirectory(), "SomeFile.txt");

            try
            {
                fileHelper.SaveFile("SomeContent", Directory.GetCurrentDirectory(), "SomeFile.txt");
            }
            catch (ArgumentException ex)
            {
                Assert.IsTrue(ex.Message.Contains("Unable to create file as already exists: "));
                Assert.IsTrue(ex.Message.Contains("SomeFile.txt"));
                throw;
            }
        }

        [TestMethod]
        public void SaveFile()
        {
            var fileHelper = new FileHelper();
            var fileName = Guid.NewGuid() + ".txt";
           
            var fullFileName = fileHelper.SaveFile("SomeContent", Directory.GetCurrentDirectory(), fileName);
            Assert.IsTrue(File.Exists(fullFileName));
        }
    }
}