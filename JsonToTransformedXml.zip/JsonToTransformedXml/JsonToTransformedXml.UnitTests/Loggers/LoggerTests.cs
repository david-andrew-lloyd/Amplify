﻿namespace JsonToTransformedXml.UnitTests.Loggers
{
    using JsonToTransformedXml.Loggers;
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Unit tests for the simple logger
    /// </summary>
    [TestClass]
    public class LoggerTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void LogNullLogEntry()
        {
            try
            {
                var logger = new Logger();
                logger.Log(null);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("entry is null or empty string value", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void LogEmptyStringLogEntry()
        {
            try
            {
                var logger = new Logger();
                logger.Log(string.Empty);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("entry is null or empty string value", ex.Message);
                throw;
            }            
        }

        [TestMethod]
        public void GetLogEntries()
        {
            var logger = new Logger();
            logger.Log("Log Entry 1");
            logger.Log("Log Entry 2");

            var log = logger.GetLogEntries();
            Assert.AreEqual(2, log.Count);
            Assert.AreEqual(log[0], "Log Entry 1");
            Assert.AreEqual(log[1], "Log Entry 2");
        }
    }
}