﻿namespace JsonToTransformedXml.Loggers
{
    using System.Collections.Generic;

    public interface ILogger
    {
        /// <summary>
        /// Method to add a log entry to the logger
        /// </summary>
        /// <param name="entry">Log entry in string format</param>
        void Log(string entry);

        /// <summary>
        /// Returns the log entries
        /// </summary>
        /// <returns></returns>
        List<string> GetLogEntries();
    }
}