﻿namespace JsonToTransformedXml.Loggers
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class implementation of a simple logger
    /// </summary>
    public class Logger : ILogger
    {
        /// <summary>
        /// Private stateful log entries
        /// </summary>
        private readonly List<string> _logEntries = new List<string>();

        /// <summary>
        /// Object to help prevent the list against concurrency
        /// </summary>
        private readonly object entriesLock = new object();

        /// <inheritdoc />
        /// <summary>
        /// Method to add a log entry to the logger
        /// </summary>
        /// <param name="entry">Log entry in string format</param>
        public void Log(string entry)
        {
            if (string.IsNullOrEmpty(entry))
                throw new ArgumentException("entry is null or empty string value");

            lock(entriesLock)
            {
                _logEntries.Add(entry);
            }           
        }

        /// <inheritdoc />
        /// <summary>
        /// Returns the log entries
        /// </summary>
        /// <returns></returns>
        public List<string> GetLogEntries()
        {
            lock (entriesLock)
            {
                return _logEntries;
            }                
        }
    }
}
