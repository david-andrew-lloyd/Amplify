﻿namespace JsonToTransformedXml.Process
{
    using Helpers;
    using Loggers;
    using Transformers;
    using System;
    using System.IO;
    using System.Xml;
    using System.Xml.XPath;
    using System.Threading.Tasks;

    /// <summary>
    /// The main workflow of this application - to transform json files to XML then XSLT transform into another shape
    /// possibly intended for transaction to some other XML based service in the workflow pipeline.
    /// </summary>
    public class ProcessChain : IProcessChain
    {
        private readonly ILogger _logger;
        private readonly IFileHelper _fileHelper;
        private readonly IXmlTransformer _xmlTransformer;
        private readonly IXslTransform _xslTransform;

        /// <summary>
        /// Constructor for the ProcessChain - we use the dependency injection pattern against interfaces
        /// as opposed to injecting in concrete types in order to follow SOLID design principles and 
        /// to make easy any unit testing we potentially want to write against the code.
        /// </summary>
        /// <param name="logger">Instance of ILogger</param>
        /// <param name="fileHelper">Instance of IFileHelper</param>
        /// <param name="xmlTransformer">Instance of IXmlTransformer</param>
        /// <param name="xslTransform">Instance of IXslTransform</param>
        public ProcessChain(ILogger logger, IFileHelper fileHelper, IXmlTransformer xmlTransformer, IXslTransform xslTransform)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _fileHelper = fileHelper ?? throw new ArgumentNullException(nameof(fileHelper));
            _xmlTransformer = xmlTransformer ?? throw new ArgumentNullException(nameof(xmlTransformer));
            _xslTransform = xslTransform ?? throw new ArgumentNullException(nameof(xslTransform));
        }

        /// <inheritdoc />
        /// <summary>
        /// Public method the initiate the main workflow against the process of this application
        /// </summary>
        /// <param name="inputDirectory">Source Directory of Files We Want to Transform</param>
        /// <param name="outputDirectory">Destination Directory of Files we have Transformed</param>
        /// <param name="fileExtensionToProcess">File Extenstions to Process - Open to Other FileTypes but Default is JSON</param>
        public async Task<int> ExecuteProcessChain(string inputDirectory, string outputDirectory, string fileExtensionToProcess = "*.json")
        {
            if (!Directory.Exists(inputDirectory))
                throw new ArgumentException(string.Concat("inputDirectory cannot be found: ", inputDirectory));

            if (string.IsNullOrEmpty(fileExtensionToProcess))
                throw new ArgumentException("fileExtensionToProcess is null or empty string");

            if (!Directory.Exists(outputDirectory))
                Directory.CreateDirectory(outputDirectory);

            var files = _fileHelper.GetFileNames(inputDirectory, fileExtensionToProcess);
            var transformDocument = new XmlDocument();
            transformDocument.LoadXml(Resources.Transform);
            var transformNavigator = transformDocument.CreateNavigator();

            foreach (var file in files)
            {
                Task<string> processFile = ProcessFile(file, outputDirectory, transformNavigator);
                string newFileName = await processFile;
                _logger.Log($"Tranformed File From: {file} to {newFileName}");                       
           }

            return files.Length;
        }

        private async Task<string> ProcessFile(string file, string outputDirectory, XPathNavigator transform)
        {
            string newFileName = string.Empty;

            await Task.Run(() =>
            {
                var document = _xmlTransformer.TransformJsonToXmlDocument(file);
                var navigator = document.CreateNavigator();
                var transformedDocument = _xslTransform.Transform(navigator, transform, null);

                var fileName = Path.GetFileName(file);
                var newShortFileNameExenstion = Path.GetExtension(fileName);
                var newShortFileName = fileName.Replace(newShortFileNameExenstion, ".xml");

                newFileName = _fileHelper.SaveFile(transformedDocument, outputDirectory, newShortFileName);
            });
    
            return newFileName;
        }
    }
}
