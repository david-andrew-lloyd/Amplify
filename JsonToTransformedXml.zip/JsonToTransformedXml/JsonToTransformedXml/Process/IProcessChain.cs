namespace JsonToTransformedXml.Process
{
    using System.Threading.Tasks;
    public interface IProcessChain
    {
        /// <summary>
        /// Public method the initiate the main workflow against the process of this application
        /// </summary>
        /// <param name="inputDirectory">Source Directory of Files We Want to Transform</param>
        /// <param name="outputDirectory">Destination Directory of Files we have Transformed</param>
        /// <param name="fileExtensionToProcess">File Extenstions to Process - Open to Other FileTypes but Default is JSON</param>
        Task<int> ExecuteProcessChain(string inputDirectory, string outputDirectory, string fileExtensionToProcess = "*.json");
    }
}