﻿namespace JsonToTransformedXml
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using Helpers;
    using Loggers;
    using Process;
    using Transformers;
    using Unity;
    using Unity.RegistrationByConvention;
    using System.Threading.Tasks;

    /// <summary>
    /// The main console program to be run
    /// </summary>
    [ExcludeFromCodeCoverage]
    class Program
    {
        /// <summary>
        /// Instance of unity container used for managed object lifetime creation
        /// </summary>
        private static readonly IUnityContainer Container = new UnityContainer();

        /// <summary>
        /// The main command window method
        /// </summary>
        /// <param name="args">Command line arguments</param>
        static void Main(string[] args)
        {
            if (args.Length != 1) throw new ArgumentException("Input Direectory of json Files Required");
            var inputDirectory = args[0];

            if (!Directory.Exists(inputDirectory))
                throw new ArgumentException(string.Concat("Unable to find directory: ", inputDirectory));

            BuildUnityContainer();
            Console.WriteLine("Please wait whilst processing Files");
            Task task = Task.Run(() => ProcessTask(inputDirectory));       
            task.Wait();
           
            var logger = Container.Resolve<ILogger>();
            foreach (var logEntry in logger.GetLogEntries())
            {
                Console.WriteLine(logEntry);
            }

            Console.WriteLine(Resources.Program_Main_Press_a_key_to_terminate_this_program_);           
            Console.ReadKey();
        }

        /// <summary>
        /// Method to process the task of transforming json files
        /// </summary>
        /// <param name="inputDirectory">The input directory where json files are stored</param>
        /// <returns>Task<int></returns>
        private static async Task<int> ProcessTask(string inputDirectory)
        {
            var processChain = Container.Resolve<IProcessChain>();           
            var outputDirectory = Path.Combine(inputDirectory, "Transformed");
            var filesProcessed = await processChain.ExecuteProcessChain(inputDirectory, outputDirectory);
            return filesProcessed;
        }

        /// <summary>
        /// Private method to build a simple unity container to encourage use of SOLID design principles
        /// </summary>
        private static void BuildUnityContainer()
        {
            Container.RegisterTypes(AllClasses.FromLoadedAssemblies(), WithMappings.FromMatchingInterface,
                WithName.Default, WithLifetime.ContainerControlled);

            Container.RegisterInstance(typeof(ILogger), new Logger());
            Container.RegisterInstance(typeof(IFileHelper), new FileHelper());
            Container.RegisterInstance(typeof(IXmlTransformer), new XmlTransformer());
            Container.RegisterInstance(typeof(IXslTransform), new XslTransform());

            Container.RegisterInstance(typeof(IProcessChain),
                new ProcessChain(Container.Resolve<ILogger>(), Container.Resolve<IFileHelper>(),
                    Container.Resolve<IXmlTransformer>(), Container.Resolve<IXslTransform>()));
        }
    }
}
