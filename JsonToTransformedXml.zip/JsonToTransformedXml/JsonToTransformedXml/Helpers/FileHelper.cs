﻿namespace JsonToTransformedXml.Helpers
{
    using System;
    using System.IO;

    /// <summary>
    /// FileHelper - typically used to locate files from given input directory
    /// </summary>
    public class FileHelper : IFileHelper
    {
        /// <inheritdoc />
        /// <summary>
        /// Gets a list of filenames for the given input directory for the given search extension
        /// </summary>
        /// <param name="inputDirectory">The given input directory</param>
        /// <param name="searchExtension">The file extension to search for</param>
        /// <returns>String array of filenames</returns>
        public string[] GetFileNames(string inputDirectory, string searchExtension)
        {
            if (!Directory.Exists(inputDirectory))
                throw new ArgumentException(string.Concat("Unable To Find inputDirectory: ", inputDirectory));

            if (string.IsNullOrEmpty(searchExtension))
                throw new ArgumentException("searchExtension appears to be null or empty string");

            return Directory.GetFiles(inputDirectory, searchExtension, SearchOption.TopDirectoryOnly);
        }

        /// <inheritdoc />
        /// <summary>
        /// Method to save string content into a file
        /// </summary>
        /// <param name="content">The content to save</param>
        /// <param name="directory">The destination directory to save the content to</param>
        /// <param name="fileName">Filename to save content into</param>
        /// <returns>The new filename</returns>
        public string SaveFile(string content, string directory, string fileName)
        {
            if (string.IsNullOrEmpty(content))
                throw new ArgumentException("content is null or empty string");

            if (!Directory.Exists(directory))
                throw new ArgumentException(string.Concat("directory does not exist: ", directory));

            if (string.IsNullOrEmpty(fileName))
                throw new ArgumentException("fileName is null or empty string");

            var fullFileName = Path.Combine(directory, fileName);

            // Note this is deliberate - if application is run twice for the same directory it will fail if the file exists
            if (File.Exists(fullFileName))
                throw new ArgumentException(string.Concat("Unable to create file as already exists: ", fullFileName));

            using (var streamWriter = new StreamWriter(fullFileName))
            {
                streamWriter.Write(content);
            }

            return fullFileName;
        }
    }
}
