﻿namespace JsonToTransformedXml.Helpers
{
    public interface IFileHelper
    {
        /// <summary>
        /// Gets a list of filenames for the given input directory for the given search extension
        /// </summary>
        /// <param name="inputDirectory">The given input directory</param>
        /// <param name="searchExtension">The file extension to search for</param>
        /// <returns>String array of filenames</returns>
        string[] GetFileNames(string inputDirectory, string searchExtension);

        /// <summary>
        /// Method to save string content into a file
        /// </summary>
        /// <param name="content">The content to save</param>
        /// <param name="directory">The destination directory to save the content to</param>
        /// <param name="fileName">Filename to save content into</param>
        /// <returns>The new filename</returns>
        string SaveFile(string content, string directory, string fileName);
    }
}