﻿namespace JsonToTransformedXml.Transformers
{    
    using Newtonsoft.Json;
    using System;
    using System.IO;
    using System.Xml;

    /// <summary>
    /// Responsible for Transforming Data/Objects To XML
    /// </summary>
    public class XmlTransformer : IXmlTransformer
    {
        /// <inheritdoc />
        /// <summary>
        /// Reads the given filename and returns XmlDocument - if not in JSON format
        /// we should encounter a deserialization error
        /// </summary>
        /// <param name="filename">The Given FileName</param>
        /// <returns>XmlDocument</returns>
        public XmlDocument TransformJsonToXmlDocument(string filename)
        {
            if (!File.Exists(filename))
                throw new ArgumentException(string.Concat("file does not exist: ", filename));

            using (var streamReader = new StreamReader(filename))
            {
                var fileContent = streamReader.ReadToEnd();
                return JsonConvert.DeserializeXmlNode(fileContent, "Insight");
            }           
        }
    }
}
