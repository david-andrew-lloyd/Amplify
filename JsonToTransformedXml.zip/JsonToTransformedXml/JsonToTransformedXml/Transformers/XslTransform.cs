﻿namespace JsonToTransformedXml.Transformers
{
    using System;
    using System.IO;
    using System.Text;
    using System.Xml.XPath;
    using System.Xml.Xsl;

    /// <summary>
    /// Type used to achieve and XSLT Compiled Transform
    /// </summary>
    public class XslTransform : IXslTransform
    {
        /// <inheritdoc />
        /// <summary>
        /// Method to transform one xml document into another using XSLT stylesheet
        /// </summary>
        /// <param name="source">The source document to transform from</param>
        /// <param name="xslt">The XSLT Script used to achieve the transform</param>
        /// <param name="argumentList">XSLT Arguments - can be used to inject parameters into XSLT script</param>
        /// <returns>Transformed XML</returns>
        public string Transform(XPathNavigator source, XPathNavigator xslt, XsltArgumentList argumentList)
        {
            if (source == null)
                throw new ArgumentNullException(nameof(source));

            if (xslt == null)
                throw new ArgumentNullException(nameof(xslt));

            if (argumentList == null)
                argumentList = new XsltArgumentList();

            var transform = new XslCompiledTransform(true);
            var output = new StringBuilder();
            transform.Load(xslt);

            using (var writer = new StringWriter(output))
            {
                transform.Transform(source, argumentList, writer);
            }

            return output.ToString();
        }
    }
}
