﻿namespace JsonToTransformedXml.Transformers
{
    using System.Xml;

    public interface IXmlTransformer
    {
        /// <summary>
        /// Reads the given filename and returns XmlDocument - if not in JSON format
        /// we should encounter a deserialization error
        /// </summary>
        /// <param name="filename">The Given FileName</param>
        /// <returns>XmlDocument</returns>
        XmlDocument TransformJsonToXmlDocument(string filename);
    }
}