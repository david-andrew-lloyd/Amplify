namespace JsonToTransformedXml.Transformers
{
    using System.Xml.XPath;
    using System.Xml.Xsl;

    public interface IXslTransform
    {
        /// <summary>
        /// Method to transform one xml document into another using XSLT stylesheet
        /// </summary>
        /// <param name="source">The source document to transform from</param>
        /// <param name="xslt">The XSLT Script used to achieve the transform</param>
        /// <param name="argumentList">XSLT Arguments - can be used to inject parameters into XSLT script</param>
        /// <returns>Transformed XML</returns>
        string Transform(XPathNavigator source, XPathNavigator xslt, XsltArgumentList argumentList);
    }
}